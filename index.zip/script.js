const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const WORLD_WIDTH = 32000; // Increased map size
const WORLD_HEIGHT = 32000; // Increased map size

// To manually change ship sizes, modify the values below.
// The number represents the ship level, and the value is the desired height in pixels.
// The width will be adjusted automatically to maintain the aspect ratio.
const shipSizes = {
    1: 120,  // Ship1 is square and bigger
    2: 150,  // Bigger
    3: 180,  // Bigger
    4: 210,  // Bigger
    5: 240,  // Bigger
    6: 270,  // Bigger
    7: 300   // Bigger
};

// Game state
let player, bots, islands, collectibles, camera, exploringCrewMembers = [];
let gameRunning = false;

const keys = {
    w: false,
    a: false,
    s: false,
    d: false,
    arrowup: false,
    arrowdown: false,
    arrowleft: false,
    arrowright: false
};

const mouse = { x: 0, y: 0 };

// Event Listeners
window.addEventListener('keydown', (e) => {
    if (e.key && e.key.toLowerCase() in keys) {
        keys[e.key.toLowerCase()] = true;
    }
});

window.addEventListener('keyup', (e) => {
    if (e.key && e.key.toLowerCase() in keys) {
        keys[e.key.toLowerCase()] = false;
    }
});

canvas.addEventListener('mousemove', (e) => {
    const rect = canvas.getBoundingClientRect();
    mouse.x = e.clientX - rect.left;
    mouse.y = e.clientY - rect.top;
});

canvas.addEventListener('click', () => {
    if (player) player.fire();
});

window.addEventListener('resize', () => {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
});

document.getElementById('weighAnchorBtn').addEventListener('click', startGame);
document.getElementById('upgrade-btn').addEventListener('click', () => upgradeShip(true));
document.getElementById('open-shop-btn').addEventListener('click', () => {
    document.getElementById('shop').style.display = 'block';
});
document.getElementById('close-shop-btn').addEventListener('click', () => {
    document.getElementById('shop').style.display = 'none';
});

document.getElementById('respawnBtn').addEventListener('click', respawnPlayer);

document.getElementById('buy-shield-btn').addEventListener('click', () => {
    if (player.gold >= 50) {
        if (!player.shieldEndTime || player.shieldEndTime < Date.now()) {
            player.gold -= 50;
            player.shieldEndTime = Date.now() + 30000; // 30 Seconds
            updateUI();
        } else {
            alert("You already have an active Shield!");
        }
    } else {
        alert("Not enough Gold! Need 50.");
    }
});

document.getElementById('buy-spyglass-btn').addEventListener('click', () => {
    if (player.gold >= 100) {
        if (!player.spyglassEndTime || player.spyglassEndTime < Date.now()) {
            player.gold -= 100;
            player.spyglassEndTime = Date.now() + 60000; // 60 Seconds
            player.viewScale = 1.5;
            updateUI();
        } else {
            alert("You already have an active Spyglass!");
        }
    } else {
        alert("Not enough Gold! Need 100.");
    }
});

document.getElementById('exploreBtn').addEventListener('click', () => {
    if (!player) return;

    let exploringIsland = null;
    for (const island of islands) {
        const dx = player.x - island.x;
        const dy = player.y - island.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        if (distance < island.size + 50) {
            exploringIsland = island;
            break;
        }
    }

    if (exploringIsland) {
        explore(exploringIsland);
    }
});

function explore(island) {
    if (player.isExploring) return;
    if (player.crew <= 1) {
        alert("You need more than one crew member to explore!");
        return;
    }

    player.isExploring = true;
    const exploringCrewCount = player.crew - 1;
    const originalCrew = player.crew;
    player.crew = 1; // One crew member stays on the ship
    document.getElementById('upgrade-ui').style.display = 'none';
    updateUI();

    const goldFound = exploringCrewCount * 2;
    player.gold += goldFound;

    const explorationResult = document.createElement('div');
    explorationResult.textContent = `You found ${goldFound} gold!`;
    explorationResult.style.position = 'absolute';
    explorationResult.style.color = 'gold';
    explorationResult.style.fontSize = '24px';
    explorationResult.style.left = `${(island.x - camera.x) * camera.zoom}px`;
    explorationResult.style.top = `${(island.y - camera.y) * camera.zoom}px`;
    document.body.appendChild(explorationResult);

    exploringCrewMembers = [];
    for (let i = 0; i < exploringCrewCount; i++) {
        exploringCrewMembers.push(new ExploringCrew(island));
    }

    // Player is vulnerable during exploration
    const originalHealth = player.health;
    player.health = 1;

    setTimeout(() => {
        player.isExploring = false;
        player.crew = originalCrew;
        player.health = originalHealth;
        document.body.removeChild(explorationResult);
        exploringCrewMembers = []; // Clear the array
        updateUI();
    }, 5000); // 5 seconds of exploration
}


// UI and Game Flow


const bgMusic = new Audio('assets/pirate.mp3');
bgMusic.loop = true;
bgMusic.volume = 0.5;


const fireSound = new Audio('assets/fire.mp3');
fireSound.volume = 0.4;

function startGame() {
    const playerName = document.getElementById('pirateName').value.trim() || 'Player';

    // Play Background Music
    bgMusic.play().catch(e => console.log("Audio play failed (user interaction needed first):", e));

    document.getElementById('main-menu').style.display = 'none';
    document.getElementById('gameCanvas').style.display = 'block';
    document.getElementById('hud').style.display = 'block';
    document.getElementById('leaderboard').style.display = 'block';
    document.getElementById('exploreUI').style.display = 'none'; // Initially hidden
    document.getElementById('upgrade-ui').style.display = 'block'; // Always visible during gameplay

    initGame(playerName);
    if (!gameRunning) {
        gameRunning = true;
        gameLoop();
    }
}

function respawnPlayer() {
    document.getElementById('respawnScreen').style.display = 'none';
    const playerName = player ? player.name : 'Player';
    initGame(playerName);
    gameRunning = true;
    gameLoop();
}

function initGame(playerName) {
    player = new Player(playerName);
    bots = Array(200).fill().map(() => new Bot());
    islands = Array(400).fill().map(() => new Island()); // Increased islands
    collectibles = Array(10000).fill().map(() => { // Increased collectibles
        const rand = Math.random();
        if (rand < 0.4) return new Gold();
        if (rand < 0.9) return new Wood();
        return new Crew();
    });

    camera = new Camera();
    player.shieldEndTime = 0;
    player.spyglassEndTime = 0;
    player.viewScale = 1;
}

function upgradeShip(isManual = false) {
    const upgradeCost = 10 + player.shipLevel * 5;
    if (player.wood >= upgradeCost) {
        player.wood -= upgradeCost;
        player.shipLevel++;
        player.updateShipStats();
        updateUI();
    } else if (isManual) {
        alert('Not enough wood to upgrade!');
    }
}

class Ship {
    constructor(name, isPlayer = false) {
        this.name = name;
        this.isPlayer = isPlayer;
        this.x = Math.random() * WORLD_WIDTH;
        this.y = Math.random() * WORLD_HEIGHT;
        this.angle = Math.random() * 2 * Math.PI;
        this.speed = 0;
        this.maxSpeed = 4; // Increased from 2
        this.acceleration = 0.1; // Increased from 0.05
        this.deceleration = 0.95;
        this.shipLevel = 1;
        this.health = 100;
        this.maxHealth = 100;
        this.cannonballs = [];
        this.lastFireTime = 0;
        this.lastFire = 0;
        this.fireRate = 1000; // 1 second
        this.gold = isPlayer ? 0 : Math.floor(Math.random() * 101);
        this.wood = 0;
        this.crew = 5;
        this.maxCrew = 10;
        this.updateShipStats();
    }

    updateShipStats() {
        this.shipImg = new Image();
        this.aspectRatio = 1;
        this.shipImg.onload = () => {
            if (this.shipImg.naturalHeight > 0) {
                this.aspectRatio = this.shipImg.naturalWidth / this.shipImg.naturalHeight;
            }
        };
        this.updateShipAppearance();
        this.maxHealth = 100 + (this.shipLevel - 1) * 20;
        this.health = this.maxHealth;
        this.maxSpeed = 4 + (this.shipLevel - 1) * 0.4; // Base 4, +0.4 per level
        this.maxCrew = 10 + (this.shipLevel - 1) * 5; // Base 10, +5 per level
    }

    updateShipAppearance() {
        this.shipImg.src = `assets/ship${this.shipLevel}.png`;
        this.size = shipSizes[this.shipLevel] || 50; // Use the shipSizes map or a default value
    }

    update() {
        // Clamp position to world bounds
        this.x = Math.max(0, Math.min(WORLD_WIDTH, this.x));
        this.y = Math.max(0, Math.min(WORLD_HEIGHT, this.y));

        // Health Regen
        if (this.health < this.maxHealth) {
            this.health = Math.min(this.maxHealth, this.health + 0.05);
        }
    }

    takeDamage(amount) {
        if (this.shieldEndTime && this.shieldEndTime > Date.now()) {
            return; // Shield active
        }
        const damageReduction = 1 - (this.shipLevel * 0.1); // 10% damage reduction per level
        this.health -= amount * damageReduction;
        if (this.health < 0) this.health = 0;
    }

    fire() {
        const now = Date.now();
        if (now - this.lastFire > 500) { // 500ms cooldown
            this.lastFire = now;

            // Play Fire Sound
            // Only play if player or near player (Distance Check)
            const dist = Math.sqrt((this.x - player.x) ** 2 + (this.y - player.y) ** 2);
            if (this === player || dist < 1200) { // Limit to screen area approx
                const sfx = fireSound.cloneNode(true);
                // Optional: Distance attenuation
                const vol = Math.max(0, 1 - dist / 1200);
                sfx.volume = vol * 0.4;
                sfx.play().catch(() => { });
            }

            let baseAngle;
            if (this === player) {
                const worldMouseX = (mouse.x / camera.zoom) + camera.x;
                const worldMouseY = (mouse.y / camera.zoom) + camera.y;
                baseAngle = Math.atan2(worldMouseY - this.y, worldMouseX - this.x);
            } else {
                baseAngle = this.angle;
            }

            let cannonballCount = 1;
            if (this.shipLevel === 3) cannonballCount = 2;
            else if (this.shipLevel === 4) cannonballCount = 3;
            else if (this.shipLevel === 5) cannonballCount = 4;
            else if (this.shipLevel === 6) cannonballCount = 5;
            else if (this.shipLevel >= 7) cannonballCount = 6;
            const spreadAngle = 0.1; // Radians

            for (let i = 0; i < cannonballCount; i++) {
                const angle = baseAngle + (i - (cannonballCount - 1) / 2) * spreadAngle;
                this.cannonballs.push({
                    x: this.x + Math.cos(angle) * 20,
                    y: this.y + Math.sin(angle) * 20,
                    angle: angle,
                    speed: 12, // Increased speed
                    radius: 8, // Reasonable size
                    life: 100,
                    owner: this
                });
            }
        }
    }

    draw(camera) {
        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.rotate(this.angle);

        // Draw ship image
        let width, height;
        if (this.shipLevel === 1) {
            width = this.size;
            height = this.size;
        } else {
            width = this.size * this.aspectRatio;
            height = this.size;
        }
        ctx.drawImage(this.shipImg, -width / 2, -height / 2, width, height);

        // Draw Shield
        if (this.shieldEndTime && this.shieldEndTime > Date.now()) {
            ctx.beginPath();
            ctx.arc(0, 0, width / 1.5, 0, Math.PI * 2);
            ctx.strokeStyle = '#00ffff';
            ctx.lineWidth = 3;
            ctx.stroke();
            ctx.fillStyle = 'rgba(0, 255, 255, 0.2)';
            ctx.fill();
        }


        // Draw Ship Glow (Level 5+)
        if (this.shipLevel >= 5) {
            ctx.save();
            ctx.shadowBlur = this.shipLevel >= 7 ? 60 : (this.shipLevel === 6 ? 40 : 20);
            ctx.shadowColor = this.shipLevel >= 7 ? '#FFD700' : (this.shipLevel === 6 ? '#FF0000' : '#8B0000');
            // Redraw ship for the glow effect
            ctx.drawImage(this.shipImg, -width / 2, -height / 2, width, height);
            ctx.restore();
        }

        ctx.restore();

        // Draw name and health bar
        ctx.save();
        ctx.translate(this.x, this.y);

        const topOfShip = -this.size / 2;

        // Draw Pirate King Crown
        if (this.rank === 1) {
            ctx.font = '40px Arial';
            ctx.textAlign = 'center';
            ctx.fillText('👑', 0, topOfShip - 50);
        }

        // Name
        ctx.fillStyle = 'white';
        ctx.font = '20px Arial';
        ctx.textAlign = 'center';
        ctx.fillText(this.name, 0, topOfShip - 25);

        // Health bar
        const healthBarWidth = 60;
        const healthBarHeight = 8;
        const healthPercentage = this.health / this.maxHealth;
        ctx.fillStyle = '#333';
        ctx.fillRect(-healthBarWidth / 2, topOfShip - 15, healthBarWidth, healthBarHeight);
        ctx.fillStyle = healthPercentage > 0.5 ? 'green' : (healthPercentage > 0.2 ? 'orange' : 'red');
        ctx.fillRect(-healthBarWidth / 2, topOfShip - 15, healthBarWidth * healthPercentage, healthBarHeight);

        ctx.restore();
    }
}

class Player extends Ship {
    constructor(name) {
        super(name, true);
        this.isExploring = false;
        this.shieldEndTime = 0;
        this.spyglassEndTime = 0;
    }

    update() {
        // Rotation
        if (keys.a || keys.arrowleft) this.angle -= 0.05;
        if (keys.d || keys.arrowright) this.angle += 0.05;

        // Movement
        if (keys.w || keys.arrowup) {
            this.speed = Math.min(this.maxSpeed, this.speed + this.acceleration);
        } else {
            this.speed *= this.deceleration;
        }
        this.x += Math.cos(this.angle) * this.speed;
        this.y += Math.sin(this.angle) * this.speed;

        if (keys.s || keys.arrowdown) {
            this.x -= Math.cos(this.angle) * this.speed * 0.5;
            this.y -= Math.sin(this.angle) * this.speed * 0.5;
        }

        if (this.shieldEndTime > 0 && Date.now() > this.shieldEndTime) {
            this.shieldEndTime = 0;
        }

        if (this.spyglassEndTime > 0 && Date.now() > this.spyglassEndTime) {
            this.spyglassEndTime = 0;
        }

        super.update(); // Updates position clamping and regen
    }
}

class ExploringCrew {
    constructor(island) {
        this.island = island;
        this.x = island.x + (Math.random() - 0.5) * island.size;
        this.y = island.y + (Math.random() - 0.5) * island.size;
        this.size = 30;
        this.speed = 0.5;
        this.targetX = island.x + (Math.random() - 0.5) * island.size;
        this.targetY = island.y + (Math.random() - 0.5) * island.size;
        this.img = new Image();
        this.img.src = 'assets/crew.png';
    }

    update() {
        const dx = this.targetX - this.x;
        const dy = this.targetY - this.y;
        const distance = Math.sqrt(dx * dx + dy * dy);

        if (distance < 5) {
            this.targetX = this.island.x + (Math.random() - 0.5) * this.island.size;
            this.targetY = this.island.y + (Math.random() - 0.5) * this.island.size;
        } else {
            const angle = Math.atan2(dy, dx);
            this.x += Math.cos(angle) * this.speed;
            this.y += Math.sin(angle) * this.speed;
        }
    }

    draw(camera) {
        ctx.drawImage(this.img, this.x - this.size / 2, this.y - this.size / 2, this.size, this.size);
    }
}

class Bot extends Ship {
    constructor() {
        super();
        const botNames = ['Arjun', 'Vikram', 'Rohan', 'Priya', 'Ananya', 'Jack', 'William', 'James', 'Emily', 'Sophia'];
        this.name = botNames[Math.floor(Math.random() * botNames.length)];
        this.x = Math.random() * WORLD_WIDTH;
        this.y = Math.random() * WORLD_HEIGHT;
        this.speed = 1;
        this.shipLevel = Math.floor(Math.random() * 2) + 1; // Start at level 1 or 2
        this.wood = 0;
        this.gold = 0;
        this.updateShipStats();
    }

    update() {
        // Auto-upgrade logic
        const upgradeCost = 10 + this.shipLevel * 5;
        if (this.wood >= upgradeCost && this.shipLevel < 7) {
            this.wood -= upgradeCost;
            this.shipLevel++;
            this.updateShipStats();
        }

        // Simple AI: move towards a target and fire
        const target = this.findTarget();
        if (target) {
            const dx = target.x - this.x;
            const dy = target.y - this.y;
            this.angle = Math.atan2(dy, dx);
            this.x += Math.cos(this.angle) * this.speed;
            this.y += Math.sin(this.angle) * this.speed;

            if (Math.sqrt(dx * dx + dy * dy) < 700) {
                // Use super.fire() to enable multi-shot logic
                super.fire();
            }
        }
        super.update();
    }

    findTarget() {
        const allShips = [player, ...bots.filter(b => b !== this)];
        let closestShip = null;
        let minDistance = Infinity;

        for (const ship of allShips) {
            const dx = ship.x - this.x;
            const dy = ship.y - this.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            if (distance < minDistance) {
                minDistance = distance;
                closestShip = ship;
            }
        }
        return closestShip;
    }

    fireAt(target) {
        // Deprecated: Now using super.fire() for multi-shot
    }
}

class Island {
    constructor() {
        this.x = Math.random() * WORLD_WIDTH;
        this.y = Math.random() * WORLD_HEIGHT;
        this.size = 300 + Math.random() * 400; // Medium-Large islands
        this.islandImg = new Image();
        const islandImages = ['assets/Island.png', 'assets/island1.png'];
        this.islandImg.src = islandImages[Math.floor(Math.random() * islandImages.length)];
    }

    draw(camera) {
        ctx.drawImage(this.islandImg, this.x - this.size, this.y - this.size, this.size * 2, this.size * 2);
    }
}

class Collectible {
    constructor() {
        this.x = Math.random() * WORLD_WIDTH;
        this.y = Math.random() * WORLD_HEIGHT;
        this.size = 10;
    }

    draw(camera) {
        // Now handled by subclasses
    }
}

class Gold extends Collectible {
    constructor() {
        super();
        this.value = 10;
        this.size = 5; // smaller size
        this.glow = 0;
        this.glowSpeed = 0.1;
    }

    draw(camera) {
        this.glow += this.glowSpeed;
        if (this.glow > 10 || this.glow < 0) {
            this.glowSpeed *= -1;
        }

        ctx.save();
        ctx.fillStyle = '#FFD700';
        ctx.shadowColor = '#FFD700';
        ctx.shadowBlur = 20 + this.glow;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
    }
}

class Wood extends Collectible {
    constructor() {
        super();
        this.value = 5;
        this.size = 45;
        this.img = new Image();
        this.img.src = 'assets/Wood.png';
    }

    draw(camera) {
        ctx.drawImage(this.img, this.x - this.size / 2, this.y - this.size / 2, this.size, this.size);
    }
}

class Crew extends Collectible {
    constructor() {
        super();
        this.value = 1;
        this.img = new Image();
        this.img.src = 'assets/crew_face.png';
    }

    draw(camera) {
        ctx.drawImage(this.img, this.x - 50, this.y - 50, 100, 100);
    }
}

class Camera {
    constructor() {
        this.x = 0;
        this.y = 0;
        this.zoom = 1;
    }

    update() {
        if (player) {
            // Smoothly adjust zoom based on player size
            let targetZoom = 1 - (player.size - 50) / 200; // Adjust the denominator for zoom sensitivity
            if (player.spyglassEndTime && player.spyglassEndTime > Date.now()) targetZoom /= 1.5; // Zoom out more active
            this.zoom += (targetZoom - this.zoom) * 0.1;
            if (this.zoom < 0.5) this.zoom = 0.5; // Set a minimum zoom level

            this.x = player.x - (canvas.width / 2) / this.zoom;
            this.y = player.y - (canvas.height / 2) / this.zoom;
        }
    }
}

function respawnBot() {
    const newBot = new Bot();
    let safeToSpawn = false;
    while (!safeToSpawn) {
        newBot.x = Math.random() * WORLD_WIDTH;
        newBot.y = Math.random() * WORLD_HEIGHT;
        safeToSpawn = true;
        for (const ship of [player, ...bots]) {
            const dx = newBot.x - ship.x;
            const dy = newBot.y - ship.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            if (distance < 200) { // Keep a safe distance from other ships
                safeToSpawn = false;
                break;
            }
        }
    }
    bots.push(newBot);
}

// Main Game Loop
function gameLoop() {
    if (!gameRunning) return;

    // Clear canvas
    ctx.fillStyle = '#87CEEB'; // Sky blue water
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Only draw game elements if player is alive
    if (player && player.health > 0) {
        // Update objects
        player.update();
        bots.forEach(bot => bot.update());
        exploringCrewMembers.forEach(crew => crew.update());
        camera.update();

        // Apply camera transformations
        ctx.save();
        ctx.scale(camera.zoom, camera.zoom);
        ctx.translate(-camera.x, -camera.y);

        // Check for proximity to islands
        let nearIsland = false;
        for (const island of islands) {
            const dx = player.x - island.x;
            const dy = player.y - island.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            if (distance < island.size + 50) { // 50 is the proximity threshold
                nearIsland = true;
                break;
            }
        }

        document.getElementById('exploreUI').style.display = nearIsland ? 'flex' : 'none';

        // Upgrade UI Force Visibility (Fix Level 3 bug)
        const upgradeUI = document.getElementById('upgrade-ui');
        if (upgradeUI && upgradeUI.style.display !== 'block') {
            upgradeUI.style.display = 'block';
        }



        // Ship vs Ship collision
        const allShips = [player, ...bots];
        for (let i = 0; i < allShips.length; i++) {
            for (let j = i + 1; j < allShips.length; j++) {
                const ship1 = allShips[i];
                const ship2 = allShips[j];

                const dx = ship2.x - ship1.x;
                const dy = ship2.y - ship1.y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                const minDistance = (ship1.size + ship2.size) / 2; // Dynamic collision distance

                if (distance < minDistance) {
                    const overlap = minDistance - distance;
                    const angle = Math.atan2(dy, dx);

                    const moveX = (overlap / 2) * Math.cos(angle);
                    const moveY = (overlap / 2) * Math.sin(angle);

                    ship1.x -= moveX;
                    ship1.y -= moveY;
                    ship2.x += moveX;
                    ship2.y += moveY;

                    // Reduce crew on collision
                    const crewLoss = 1;
                    ship1.crew -= crewLoss;
                    ship2.crew -= crewLoss;

                    if (ship1.crew <= 0) {
                        if (ship1 instanceof Bot) {
                            bots.splice(bots.indexOf(ship1), 1);
                            respawnBot();
                        } else {
                            gameRunning = false;
                            document.getElementById('respawnScreen').style.display = 'block';
                        }
                    }

                    if (ship2.crew <= 0) {
                        if (ship2 instanceof Bot) {
                            bots.splice(bots.indexOf(ship2), 1);
                            respawnBot();
                        } else {
                            gameRunning = false;
                            document.getElementById('respawnScreen').style.display = 'block';
                        }
                    }
                }
            }
        }

        // Ship vs Island collision
        for (const ship of allShips) {
            for (const island of islands) {
                const dx = ship.x - island.x;
                const dy = ship.y - island.y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                const minDistance = island.size + 20; // 20 is ship radius

                if (distance < minDistance) {
                    const overlap = minDistance - distance;
                    const angle = Math.atan2(dy, dx);

                    ship.x += overlap * Math.cos(angle);
                    ship.y += overlap * Math.sin(angle);
                }
            }
        }

        // Update all cannonballs
        const allCannonballs = [player, ...bots].flatMap(ship => ship.cannonballs);
        for (let i = allCannonballs.length - 1; i >= 0; i--) {
            const cb = allCannonballs[i];
            cb.x += Math.cos(cb.angle) * cb.speed;
            cb.y += Math.sin(cb.angle) * cb.speed;
            cb.life--;
            if (cb.life <= 0) {
                cb.owner.cannonballs.splice(cb.owner.cannonballs.indexOf(cb), 1);
            }
        }

        // Collision detection
        // Cannonballs vs Ships
        for (const cb of allCannonballs) {
            const ships = [player, ...bots];
            for (const ship of ships) {
                if (cb.owner !== ship) {
                    const dx = cb.x - ship.x;
                    const dy = cb.y - ship.y;
                    const distance = Math.sqrt(dx * dx + dy * dy);
                    if (distance < ship.size / 2) { // Collision radius based on ship size
                        ship.health -= 10;
                        if (ship.health < 0) ship.health = 0; // Prevent negative health
                        cb.owner.cannonballs.splice(cb.owner.cannonballs.indexOf(cb), 1);
                        if (ship.health <= 0) {
                            if (ship instanceof Bot) {
                                bots.splice(bots.indexOf(ship), 1);
                                if (cb.owner === player) player.gold += 10;
                                respawnBot();
                            } else {
                                // Player died
                                gameRunning = false;
                                document.getElementById('respawnScreen').style.display = 'block';
                            }
                        }
                        break;
                    }
                }
            }
        }

        // Ships vs Collectibles (Player AND Bots)
        const allShipsForCollectibles = [player, ...bots];
        for (let i = collectibles.length - 1; i >= 0; i--) {
            const collectible = collectibles[i];
            let collected = false;

            for (const ship of allShipsForCollectibles) {
                const dx = ship.x - collectible.x;
                const dy = ship.y - collectible.y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                const attractionRadius = 150 + (ship.size || 50); // Dynamic Collection Radius

                if (distance < (ship.size / 2)) {
                    if (collectible instanceof Gold) ship.gold = (ship.gold || 0) + collectible.value;
                    if (collectible instanceof Wood) {
                        ship.wood = (ship.wood || 0) + collectible.value;
                    }
                    if (collectible instanceof Crew) ship.crew = Math.min(ship.maxCrew, ship.crew + collectible.value);

                    // If it's the player, update UI immediately for responsiveness
                    if (ship === player) {
                        updateUI();
                    }

                    collectibles.splice(i, 1);
                    collected = true;
                    break; // One collectible can only be collected by one ship
                } else if (distance < attractionRadius) {
                    // Attract the collectible towards the ship
                    const angle = Math.atan2(dy, dx);
                    const moveSpeed = 3; // Faster attraction
                    collectible.x += Math.cos(angle) * moveSpeed;
                    collectible.y += Math.sin(angle) * moveSpeed;
                }
            }
            if (collected) continue;
        }

        // Periodically update UI for leaderboard (every 60 frames approx 1 second)
        // Using a frame counter or simple timestamp check
        if (!window.lastUIUpdate || Date.now() - window.lastUIUpdate > 500) {
            updateUI();
            window.lastUIUpdate = Date.now();
        }


        // Draw objects
        islands.forEach(island => island.draw(camera));
        collectibles.forEach(collectible => collectible.draw(camera));
        exploringCrewMembers.forEach(crew => crew.draw(camera));
        player.draw(camera);
        bots.forEach(bot => bot.draw(camera));

        // Draw Cannonballs with Trails
        allCannonballs.forEach(cb => {
            // Update Trail
            if (!cb.trail) cb.trail = [];
            cb.trail.push({ x: cb.x, y: cb.y, alpha: 1.0 });
            if (cb.trail.length > 20) cb.trail.shift(); // Limit trail length

            // Draw Trail
            if (cb.trail.length > 1) {
                // Fire effect parameters
                for (let i = 0; i < cb.trail.length; i++) {
                    const point = cb.trail[i];
                    const size = (i / cb.trail.length) * 10; // Trail gets wider towards the cannonball? or thinner? let's go with fading size
                    const alpha = point.alpha;

                    ctx.beginPath();
                    ctx.arc(point.x, point.y, size, 0, Math.PI * 2);
                    // Gradient from yellow to red to smoke
                    if (i > cb.trail.length * 0.7) ctx.fillStyle = `rgba(255, 100, 0, ${alpha})`; // Orange/Red near head
                    else if (i > cb.trail.length * 0.4) ctx.fillStyle = `rgba(200, 50, 0, ${alpha * 0.7})`; // Darker red middle
                    else ctx.fillStyle = `rgba(100, 100, 100, ${alpha * 0.5})`; // Smoke tail

                    ctx.fill();
                    point.alpha -= 0.05; // Fade out points
                }
            }

            // Draw the cannonball itself
            ctx.fillStyle = '#111';
            ctx.beginPath();
            ctx.arc(cb.x, cb.y, cb.radius || 8, 0, Math.PI * 2);
            ctx.fill();

            // Highlight on ball
            ctx.fillStyle = '#444';
            ctx.beginPath();
            ctx.arc(cb.x - 2, cb.y - 2, 3, 0, Math.PI * 2);
            ctx.fill();
        });

        ctx.restore();
    }

    updateUI(); // Ensure UI is updated at end of loop too
    requestAnimationFrame(gameLoop);
}

// ---------------------------------------------------------
// HUD AND STATS CALCULATIONS (Fixing the "not upgrade correctly" issue)
// ---------------------------------------------------------
function updateUI() {
    if (!player) return;
    const goldStat = document.getElementById('gold-stat');
    const woodStat = document.getElementById('wood-stat');
    const crewStat = document.getElementById('crew-stat');
    const shipLevelEl = document.getElementById('ship-level');
    const upgradeCostEl = document.getElementById('upgrade-cost');
    const upgradeUI = document.getElementById('upgrade-ui');
    const buffsContainer = document.getElementById('buffs-container');

    // Buffs Display
    if (buffsContainer) {
        let buffsHTML = '';
        const now = Date.now();
        if (player.shieldEndTime > now) {
            const timeLeft = Math.ceil((player.shieldEndTime - now) / 1000);
            buffsHTML += `<div class="buff-item" style="border-color: #00ffff;">🛡️ Shield: ${timeLeft}s</div>`;
        }
        if (player.spyglassEndTime > now) {
            const timeLeft = Math.ceil((player.spyglassEndTime - now) / 1000);
            buffsHTML += `<div class="buff-item" style="border-color: #ffd700;">🔭 Spyglass: ${timeLeft}s</div>`;
        }
        buffsContainer.innerHTML = buffsHTML;
    }

    if (goldStat) goldStat.textContent = player.gold;
    if (woodStat) woodStat.textContent = player.wood;
    if (crewStat) crewStat.textContent = `${player.crew}/${player.maxCrew}`;
    if (shipLevelEl) shipLevelEl.textContent = player.shipLevel;

    // Hide Upgrade UI if max level
    if (player.shipLevel >= 7) {
        if (upgradeUI) upgradeUI.style.display = 'none';
    } else {
        if (upgradeUI) upgradeUI.style.display = 'block';
    }

    // Upgrade Progress Logic
    if (upgradeCostEl && player.shipLevel < 7) {
        const upgradeCost = 10 + player.shipLevel * 5;
        upgradeCostEl.textContent = upgradeCost + ' Wood';

        const woodNeeded = Math.max(0, upgradeCost - player.wood);
        const woodProgress = Math.min(100, (player.wood / upgradeCost) * 100); // Clamp to 100%

        document.getElementById('upgrade-progress').style.width = `${woodProgress}%`;

        if (woodNeeded <= 0) {
            document.getElementById('upgrade-progress-text').textContent = "READY TO UPGRADE!";
            document.getElementById('upgrade-progress-text').style.color = "#00ff00";
            document.getElementById('upgrade-progress-text').style.fontWeight = "bold";
        } else {
            document.getElementById('upgrade-progress-text').textContent = `${woodNeeded} more wood needed`;
            document.getElementById('upgrade-progress-text').style.color = "white";
            document.getElementById('upgrade-progress-text').style.fontWeight = "normal";
        }
    }


    // Update leaderboard (Titling Logic)
    const titles = [
        "Pirate King", "Grand Admiral", "Fleet Commander", "Captain", "Commander",
        "Lieutenant", "Ensign", "Boatswain", "Sailor", "Powder Monkey"
    ];

    const leaderboardList = document.getElementById('leaderboard-list');
    if (leaderboardList) {
        leaderboardList.innerHTML = '';
        const allShips = [player, ...bots].sort((a, b) => (b.gold || 0) - (a.gold || 0));

        // Reset ranks and assign new ones
        [player, ...bots].forEach(s => s.rank = -1);
        allShips.forEach((s, i) => s.rank = i + 1);

        const playerRank = allShips.findIndex(ship => ship === player) + 1;

        const top10 = allShips.slice(0, 10);
        top10.forEach((ship, index) => {
            const li = document.createElement('li');
            const rankTitle = titles[index] || "Scallywag";
            li.innerHTML = `<span>${index + 1}. [${rankTitle}] ${ship.name}</span><span>${ship.gold || 0}</span>`;
            if (ship === player) li.style.fontWeight = 'bold';
            leaderboardList.appendChild(li);
        });

        // Set Footer with Player Rank
        const footer = document.getElementById('leaderboard-footer');
        if (footer) {
            const myTitle = titles[playerRank - 1] || "Scallywag";
            footer.textContent = `Your Rank: ${playerRank} [${myTitle}]`;
        }


        if (playerRank > 10) {
            leaderboardList.appendChild(document.createElement('li')).textContent = "...";
            const playerLi = document.createElement('li');
            playerLi.innerHTML = `<span>${playerRank}. ${player.name}</span><span>${player.gold || 0}</span>`;
            playerLi.style.fontWeight = 'bold';
            leaderboardList.appendChild(playerLi);
        }
    }
}